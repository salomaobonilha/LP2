﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if(Double.TryParse(txtNum1.Text, out numero1)||(Double.TryParse(txtNum2.Text, out numero2)))
                {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
            }
            else {
                MessageBox.Show("Número inválido");

            }
              

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) || Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Número inválido");

            }
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) || (Double.TryParse(txtNum2.Text, out numero2)))
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Número inválido");

            }
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && (Double.TryParse(txtNum2.Text, out numero2)) && (numero2!=0))
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Número inválido");

            }
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            Close();        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
        }

        private void Num2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido!");
            }
        }

   
        private void Num1_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtNum1.Text, out numero1 ))
            {
                MessageBox.Show("Número 1 inválido!");
            }
        }
    }
}
