﻿namespace Atividade3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            peso = new MaskedTextBox();
            imc = new MaskedTextBox();
            altura = new MaskedTextBox();
            lbl1 = new Label();
            lbl2 = new Label();
            lbl3 = new Label();
            categoria = new MaskedTextBox();
            lbl4 = new Label();
            btn1 = new Button();
            SuspendLayout();
            // 
            // peso
            // 
            peso.Location = new Point(167, 40);
            peso.Mask = "000.0";
            peso.Name = "peso";
            peso.Size = new Size(125, 27);
            peso.TabIndex = 0;
            peso.Validated += peso_Validated;
            // 
            // imc
            // 
            imc.Location = new Point(167, 183);
            imc.Name = "imc";
            imc.Size = new Size(125, 27);
            imc.TabIndex = 1;
            // 
            // altura
            // 
            altura.Location = new Point(167, 105);
            altura.Mask = "0.00";
            altura.Name = "altura";
            altura.Size = new Size(125, 27);
            altura.TabIndex = 2;
            altura.Validated += altura_Validated;
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.Location = new Point(69, 47);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(44, 20);
            lbl1.TabIndex = 3;
            lbl1.Text = "PESO";
            lbl1.Click += label1_Click_1;
            // 
            // lbl2
            // 
            lbl2.AutoSize = true;
            lbl2.Location = new Point(60, 108);
            lbl2.Name = "lbl2";
            lbl2.Size = new Size(62, 20);
            lbl2.TabIndex = 4;
            lbl2.Text = "ALTURA";
            // 
            // lbl3
            // 
            lbl3.AutoSize = true;
            lbl3.Location = new Point(74, 190);
            lbl3.Name = "lbl3";
            lbl3.Size = new Size(35, 20);
            lbl3.TabIndex = 5;
            lbl3.Text = "IMC";
            lbl3.Click += label3_Click;
            // 
            // categoria
            // 
            categoria.Location = new Point(167, 255);
            categoria.Name = "categoria";
            categoria.Size = new Size(125, 27);
            categoria.TabIndex = 6;
            // 
            // lbl4
            // 
            lbl4.AutoSize = true;
            lbl4.Location = new Point(48, 262);
            lbl4.Name = "lbl4";
            lbl4.Size = new Size(87, 20);
            lbl4.TabIndex = 7;
            lbl4.Text = "CATEGORIA";
            // 
            // btn1
            // 
            btn1.Location = new Point(355, 154);
            btn1.Name = "btn1";
            btn1.Size = new Size(94, 29);
            btn1.TabIndex = 8;
            btn1.Text = "CALCULAR";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn1);
            Controls.Add(lbl4);
            Controls.Add(categoria);
            Controls.Add(lbl3);
            Controls.Add(lbl2);
            Controls.Add(lbl1);
            Controls.Add(altura);
            Controls.Add(imc);
            Controls.Add(peso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox peso;
        private MaskedTextBox imc;
        private MaskedTextBox altura;
        private Label lbl1;
        private Label lbl2;
        private Label lbl3;
        private MaskedTextBox categoria;
        private Label lbl4;
        private Button btn1;
    }
}