namespace Atividade3
{
    public partial class Form1 : Form
    {
        double weight, height, bmi;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void peso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(peso.Text, out weight))
            {
                MessageBox.Show("Peso inv�lido!");
            }
            else
            {
                if (weight <= 0)
                {
                    MessageBox.Show("peso n�o pode ser <= 0");
                }
            }
        }

        private void altura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(altura.Text, out height))
            {
                MessageBox.Show("Altura inv�lida!");
            }
            else
            {
                if (height <= 0)
                {
                    MessageBox.Show("Altura n�o pode ser <= 0");
                }
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            {
                if ((!double.TryParse(altura.Text, out height)) ||
                   (!double.TryParse(peso.Text, out weight)))
                {
                    MessageBox.Show("Valores inv�lidos");
                }
                else
                {
                    if ((height <= 0 || weight <= 0))
                    {
                        MessageBox.Show("Valores n�o podem ser <= 0");
                    }
                    else
                    {
                        bmi = weight / Math.Pow(height, 2);
                        imc.Text = bmi.ToString("N2");
                    }

                }
                if (bmi<18.5)
                {
                    categoria.Text = ("Magreza");
                }
                else if (bmi < 24.9)
                {
                    categoria.Text = ("Normal");
                }
                else if (bmi < 29.9)
                {
                    categoria.Text = ("Sobrepeso (grau I)");
                }
                else if (bmi < 39.9)
                {
                    categoria.Text = ("Obesidade (Grau II)");
                }
                else 
                {
                    categoria.Text = ("Obesidade grave (Grau III)");
                }
            }
        }
    }
}