﻿namespace Atividade5._1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxAliqInss = new System.Windows.Forms.MaskedTextBox();
            this.numeroFilhosMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.salarioBrutoMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoIrpf = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoInss = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliqIrpf = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.calcularButton = new System.Windows.Forms.Button();
            this.limparButton = new System.Windows.Forms.Button();
            this.masculinoRadioButton = new System.Windows.Forms.RadioButton();
            this.femininoRadioButton = new System.Windows.Forms.RadioButton();
            this.solteiroRadioButton = new System.Windows.Forms.RadioButton();
            this.casadoRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // mskbxAliqInss
            // 
            this.mskbxAliqInss.Location = new System.Drawing.Point(157, 147);
            this.mskbxAliqInss.Name = "mskbxAliqInss";
            this.mskbxAliqInss.Size = new System.Drawing.Size(105, 22);
            this.mskbxAliqInss.TabIndex = 0;
            // 
            // numeroFilhosMaskedTextBox
            // 
            this.numeroFilhosMaskedTextBox.Location = new System.Drawing.Point(157, 99);
            this.numeroFilhosMaskedTextBox.Name = "numeroFilhosMaskedTextBox";
            this.numeroFilhosMaskedTextBox.Size = new System.Drawing.Size(105, 22);
            this.numeroFilhosMaskedTextBox.TabIndex = 1;
            // 
            // salarioBrutoMaskedTextBox
            // 
            this.salarioBrutoMaskedTextBox.Location = new System.Drawing.Point(157, 53);
            this.salarioBrutoMaskedTextBox.Name = "salarioBrutoMaskedTextBox";
            this.salarioBrutoMaskedTextBox.Size = new System.Drawing.Size(105, 22);
            this.salarioBrutoMaskedTextBox.TabIndex = 4;
            // 
            // mskbxSalarioLiquido
            // 
            this.mskbxSalarioLiquido.Location = new System.Drawing.Point(157, 389);
            this.mskbxSalarioLiquido.Name = "mskbxSalarioLiquido";
            this.mskbxSalarioLiquido.Size = new System.Drawing.Size(100, 22);
            this.mskbxSalarioLiquido.TabIndex = 5;
            // 
            // mskbxSalarioFamilia
            // 
            this.mskbxSalarioFamilia.Location = new System.Drawing.Point(157, 345);
            this.mskbxSalarioFamilia.Name = "mskbxSalarioFamilia";
            this.mskbxSalarioFamilia.Size = new System.Drawing.Size(105, 22);
            this.mskbxSalarioFamilia.TabIndex = 6;
            // 
            // mskbxDescontoIrpf
            // 
            this.mskbxDescontoIrpf.Location = new System.Drawing.Point(157, 298);
            this.mskbxDescontoIrpf.Name = "mskbxDescontoIrpf";
            this.mskbxDescontoIrpf.Size = new System.Drawing.Size(105, 22);
            this.mskbxDescontoIrpf.TabIndex = 7;
            // 
            // mskbxDescontoInss
            // 
            this.mskbxDescontoInss.Location = new System.Drawing.Point(157, 246);
            this.mskbxDescontoInss.Name = "mskbxDescontoInss";
            this.mskbxDescontoInss.Size = new System.Drawing.Size(100, 22);
            this.mskbxDescontoInss.TabIndex = 8;
            // 
            // mskbxAliqIrpf
            // 
            this.mskbxAliqIrpf.Location = new System.Drawing.Point(157, 196);
            this.mskbxAliqIrpf.Name = "mskbxAliqIrpf";
            this.mskbxAliqIrpf.Size = new System.Drawing.Size(105, 22);
            this.mskbxAliqIrpf.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Salário bruto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "Número de filhos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 16);
            this.label3.TabIndex = 12;
            this.label3.Text = "Alíquota INSS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "Alíquota IRPF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 252);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Desconto INSS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 304);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 16);
            this.label6.TabIndex = 15;
            this.label6.Text = "Desconto IRPF";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 351);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Salário família";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(46, 395);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Salário líquido";
            // 
            // calcularButton
            // 
            this.calcularButton.Location = new System.Drawing.Point(403, 314);
            this.calcularButton.Name = "calcularButton";
            this.calcularButton.Size = new System.Drawing.Size(75, 23);
            this.calcularButton.TabIndex = 18;
            this.calcularButton.Text = "Calcular";
            this.calcularButton.UseVisualStyleBackColor = true;
            this.calcularButton.Click += new System.EventHandler(this.calcularButton_Click);
            // 
            // limparButton
            // 
            this.limparButton.Location = new System.Drawing.Point(403, 361);
            this.limparButton.Name = "limparButton";
            this.limparButton.Size = new System.Drawing.Size(75, 23);
            this.limparButton.TabIndex = 19;
            this.limparButton.Text = "Limpar";
            this.limparButton.UseVisualStyleBackColor = true;
            // 
            // masculinoRadioButton
            // 
            this.masculinoRadioButton.AutoSize = true;
            this.masculinoRadioButton.Location = new System.Drawing.Point(30, 32);
            this.masculinoRadioButton.Name = "masculinoRadioButton";
            this.masculinoRadioButton.Size = new System.Drawing.Size(39, 20);
            this.masculinoRadioButton.TabIndex = 20;
            this.masculinoRadioButton.TabStop = true;
            this.masculinoRadioButton.Text = "M";
            this.masculinoRadioButton.UseVisualStyleBackColor = true;
            // 
            // femininoRadioButton
            // 
            this.femininoRadioButton.AutoSize = true;
            this.femininoRadioButton.Location = new System.Drawing.Point(32, 58);
            this.femininoRadioButton.Name = "femininoRadioButton";
            this.femininoRadioButton.Size = new System.Drawing.Size(36, 20);
            this.femininoRadioButton.TabIndex = 21;
            this.femininoRadioButton.TabStop = true;
            this.femininoRadioButton.Text = "F";
            this.femininoRadioButton.UseVisualStyleBackColor = true;
            // 
            // solteiroRadioButton
            // 
            this.solteiroRadioButton.AutoSize = true;
            this.solteiroRadioButton.Location = new System.Drawing.Point(32, 25);
            this.solteiroRadioButton.Name = "solteiroRadioButton";
            this.solteiroRadioButton.Size = new System.Drawing.Size(74, 20);
            this.solteiroRadioButton.TabIndex = 22;
            this.solteiroRadioButton.TabStop = true;
            this.solteiroRadioButton.Text = "Solteiro";
            this.solteiroRadioButton.UseVisualStyleBackColor = true;
            // 
            // casadoRadioButton
            // 
            this.casadoRadioButton.AutoSize = true;
            this.casadoRadioButton.Location = new System.Drawing.Point(30, 64);
            this.casadoRadioButton.Name = "casadoRadioButton";
            this.casadoRadioButton.Size = new System.Drawing.Size(76, 20);
            this.casadoRadioButton.TabIndex = 23;
            this.casadoRadioButton.TabStop = true;
            this.casadoRadioButton.Text = "Casado";
            this.casadoRadioButton.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.femininoRadioButton);
            this.groupBox1.Controls.Add(this.masculinoRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(338, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.solteiroRadioButton);
            this.groupBox2.Controls.Add(this.casadoRadioButton);
            this.groupBox2.Location = new System.Drawing.Point(338, 172);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Estado civil";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.limparButton);
            this.Controls.Add(this.calcularButton);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mskbxAliqIrpf);
            this.Controls.Add(this.mskbxDescontoInss);
            this.Controls.Add(this.mskbxDescontoIrpf);
            this.Controls.Add(this.mskbxSalarioFamilia);
            this.Controls.Add(this.mskbxSalarioLiquido);
            this.Controls.Add(this.salarioBrutoMaskedTextBox);
            this.Controls.Add(this.numeroFilhosMaskedTextBox);
            this.Controls.Add(this.mskbxAliqInss);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxAliqInss;
        private System.Windows.Forms.MaskedTextBox numeroFilhosMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox salarioBrutoMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioFamilia;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoIrpf;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoInss;
        private System.Windows.Forms.MaskedTextBox mskbxAliqIrpf;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button calcularButton;
        private System.Windows.Forms.Button limparButton;
        private System.Windows.Forms.RadioButton masculinoRadioButton;
        private System.Windows.Forms.RadioButton femininoRadioButton;
        private System.Windows.Forms.RadioButton solteiroRadioButton;
        private System.Windows.Forms.RadioButton casadoRadioButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

