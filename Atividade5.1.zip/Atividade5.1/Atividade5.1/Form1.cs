﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void calcularButton_Click(object sender, EventArgs e)
        {
            double salarioBruto = double.Parse(salarioBrutoMaskedTextBox.Text);
            int numeroFilhos = int.Parse(numeroFilhosMaskedTextBox.Text);

            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;

            // Cálculo para INSS
            if (salarioBruto <= 800.47)
            {
                mskbxAliqInss.Text = "7,65%";
                descontoINSS = 0.0765 * salarioBruto;
            }
            else if (salarioBruto <= 1050)
            {
                mskbxAliqInss.Text = "8,65%";
                descontoINSS = 0.0865 * salarioBruto;
            }
            else if (salarioBruto <= 1400.77)
            {
                mskbxAliqInss.Text = "9,00%";
                descontoINSS = 0.09 * salarioBruto;
            }
            else if (salarioBruto <= 2801.56)
            {
                mskbxAliqInss.Text = "11,00%";
                descontoINSS = 0.11 * salarioBruto;
            }
            else
            {
                mskbxAliqInss.Text = "Teto (308.17)";
                descontoINSS = 308.17;
            }

            // Cálculo para IRPF
            if (salarioBruto > 1257.12 && salarioBruto <= 2512.08)
            {
                mskbxAliqIrpf.Text = "15,00%";
                descontoIRPF = 0.15 * salarioBruto;
            }
            else if (salarioBruto > 2512.08)
            {
                mskbxAliqIrpf.Text = "27,50%";
                descontoIRPF = 0.275 * salarioBruto;
            }
            else
            {
                mskbxAliqIrpf.Text = "Isento";
            }

            // Cálculo para Salário Família
            if (salarioBruto <= 435.52)
            {
                salarioFamilia = 22.33 * numeroFilhos;
            }
            else if (salarioBruto <= 654.61)
            {
                salarioFamilia = 15.74 * numeroFilhos;
            }

            // Verificar sexo e estado civil
            string sexo = "";
            if (masculinoRadioButton.Checked)
            {
                sexo = "Masculino";
            }
            else if (femininoRadioButton.Checked)
            {
                sexo = "Feminino";
            }

            string estadoCivil = "";
            if (solteiroRadioButton.Checked)
            {
                estadoCivil = "Solteiro(a)";
            }
            else if (casadoRadioButton.Checked)
            {
                estadoCivil = "Casado(a)";
            }
            // Cálculo para Salário Líquido
            salarioLiquido = salarioBruto - descontoINSS - descontoIRPF;

            // Exibir os resultados
            mskbxDescontoInss.Text = descontoINSS.ToString("F2");
            mskbxDescontoIrpf.Text = descontoIRPF.ToString("F2");
            mskbxSalarioFamilia.Text = salarioFamilia.ToString("F2");
            mskbxSalarioLiquido.Text = salarioLiquido.ToString("F2");

            string mensagem = $"Sexo: {sexo}\nEstado Civil: {estadoCivil}\n\nDesconto INSS: R$ {descontoINSS:F2}\nDesconto IRPF: R$ {descontoIRPF:F2}\nSalário Família: R$ {salarioFamilia:F2}\nSalário Líquido: R$ {salarioLiquido:F2}";

            MessageBox.Show(mensagem, "Resultados", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void limparButton_Click(object sender, EventArgs e)
        {
            salarioBrutoMaskedTextBox.Clear();
            numeroFilhosMaskedTextBox.Clear();
            mskbxAliqInss.Clear();
            mskbxAliqIrpf.Clear();
            mskbxDescontoInss.Clear();
            mskbxDescontoIrpf.Clear();
            mskbxSalarioFamilia.Clear();
            mskbxSalarioLiquido.Clear();
            masculinoRadioButton.Checked = true;
            solteiroRadioButton.Checked = true;

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
