﻿namespace Atividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEsp = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxtFrase
            // 
            this.rchTxtFrase.Location = new System.Drawing.Point(281, 40);
            this.rchTxtFrase.Name = "rchTxtFrase";
            this.rchTxtFrase.Size = new System.Drawing.Size(100, 96);
            this.rchTxtFrase.TabIndex = 0;
            this.rchTxtFrase.Text = "";
            // 
            // btnEsp
            // 
            this.btnEsp.Location = new System.Drawing.Point(116, 196);
            this.btnEsp.Name = "btnEsp";
            this.btnEsp.Size = new System.Drawing.Size(102, 90);
            this.btnEsp.TabIndex = 1;
            this.btnEsp.Text = "Calcular espaços em branco";
            this.btnEsp.UseVisualStyleBackColor = true;
            this.btnEsp.Click += new System.EventHandler(this.BtnEsp_Click);
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(281, 196);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(102, 90);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "Calcular aparecimentos da letra \"R\"";
            this.btnR.UseVisualStyleBackColor = true;
            // 
            // btnPares
            // 
            this.btnPares.Location = new System.Drawing.Point(467, 196);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(104, 90);
            this.btnPares.TabIndex = 3;
            this.btnPares.Text = "Calcular número de pares de linhas";
            this.btnPares.UseVisualStyleBackColor = true;
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnEsp);
            this.Controls.Add(this.rchTxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtFrase;
        private System.Windows.Forms.Button btnEsp;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnPares;
    }
}