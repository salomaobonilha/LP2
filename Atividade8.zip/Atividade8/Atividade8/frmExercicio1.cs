﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio1 : Form

    {
        private string inputString = string.Empty;
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnEsp_Click(object sender, EventArgs e)
        {
            int i, c;
            c = 0;
            for (i = 0; i < rchTxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchTxtFrase.Text[i]))
                {
                    c++;
                }
            }
            MessageBox.Show("O número de espaços em branco é:" + c);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int rCount = rchTxtFrase.Text.Count(c => c == 'R' || c == 'r');
            MessageBox.Show($"Número de vezes que a letra 'R' aparece: {rCount}");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int pairCount = 0;
            for (int i = 0; i < rchTxtFrase.Text.Length - 1; i++)
            {
                if (rchTxtFrase.Text[i] == rchTxtFrase.Text[i + 1])
                {
                    pairCount++;
                }
            }
            MessageBox.Show($"Número de pares de letras: {pairCount}");
        }
    }
}


