﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnEsp_Click(object sender, EventArgs e)
        {
            int i,c;
            c = 0;
            for (i = 0; i < rchTxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchTxtFrase.Text[i]){
                    c++;
                }
            }
            MessageBox.Show("O número de espaços em branco é:" + c);
        }
    }
}
