﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox.Text, out int n) && n > 0)
            {
                double h = 0;
                for (int i = 1; i <= n; i++)
                {
                    h += 1.0 / i;
                }
                MessageBox.Show($"O número H é: {h}");
            }
            else
            {
                MessageBox.Show("Por favor, insira um número inteiro positivo.");
            }
        }
    }
}
