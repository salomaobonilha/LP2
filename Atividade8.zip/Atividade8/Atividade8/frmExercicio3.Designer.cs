﻿namespace Atividade8
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkPalindromeButton = new System.Windows.Forms.Button();
            this.textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // checkPalindromeButton
            // 
            this.checkPalindromeButton.Location = new System.Drawing.Point(303, 187);
            this.checkPalindromeButton.Name = "checkPalindromeButton";
            this.checkPalindromeButton.Size = new System.Drawing.Size(155, 55);
            this.checkPalindromeButton.TabIndex = 0;
            this.checkPalindromeButton.Text = "Checar palíndromos";
            this.checkPalindromeButton.UseVisualStyleBackColor = true;
            this.checkPalindromeButton.Click += new System.EventHandler(this.checkPalindromeButton_Click);
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(324, 91);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(100, 22);
            this.textBox.TabIndex = 1;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.checkPalindromeButton);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button checkPalindromeButton;
        private System.Windows.Forms.TextBox textBox;
    }
}