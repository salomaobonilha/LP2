﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void checkPalindromeButton_Click(object sender, EventArgs e)
        {
            string input = textBox.Text.Trim().ToUpper();

            
            input = new string(input.Where(c => !Char.IsWhiteSpace(c)).ToArray());

            
            input = RemoveAccents(input);

            string reversedInput = ReverseString(input);

            if (input == reversedInput)
            {
                MessageBox.Show("É um palíndromo!");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo.");
            }
        }

        private string RemoveAccents(string input)
        {
            byte[] bytes = Encoding.GetEncoding("Cyrillic").GetBytes(input);
            return Encoding.ASCII.GetString(bytes);
        }

        private string ReverseString(string input)
        {
            char[] charArray = input.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
    }
}
    