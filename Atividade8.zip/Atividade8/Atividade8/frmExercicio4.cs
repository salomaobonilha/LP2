﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            string nome = nomeTextBox.Text;
            string cargo = cargoTextBox.Text;
            string matricula = matriculaTextBox.Text;
            int producao = int.Parse(producaoTextBox.Text);
            double salario = double.Parse(salarioTextBox.Text);
            double gratificacao = double.Parse(gratificacaoTextBox.Text);

            double a = GetSalarioCargo(cargo);
            int b = producao >= 100 ? 1 : 0;
            int c = producao >= 120 ? 1 : 0;
            int d = producao >= 150 ? 1 : 0;

            double salarioBruto = a + a * (0.05 * b + 0.1 * c + 0.1 * d) + gratificacao;

            if (salarioBruto > 7000 && d == 0 && gratificacao == 0)
            {
                MessageBox.Show("O salário bruto não pode ultrapassar 7.000,00 sem gratificação e produção >= 150.");
                return;
            }

            MessageBox.Show($"Nome: {nome}\nCargo: {cargo}\nMatrícula: {matricula}\nSalário Bruto: {salarioBruto.ToString("C2")}");
        }

        private double GetSalarioCargo(string cargo)
        {

            if (cargo == "Gerente")
            {
                return 5000;
            }
            else if (cargo == "Analista")
            {
                return 4000;
            }
            else if (cargo == "Assistente")
            {
                return 3000;
            }
            else
            {
                return 0; 
            }
        }
    }
}