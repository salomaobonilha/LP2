﻿namespace WindowsFormsApp1
{
    partial class btnNewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnShowReverse = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnRemoveOtavio = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(28, 48);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(199, 65);
            this.btnLoad.TabIndex = 0;
            this.btnLoad.Text = "Ex. 1 Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.BtnLoad_Click);
            // 
            // btnShowReverse
            // 
            this.btnShowReverse.Location = new System.Drawing.Point(28, 121);
            this.btnShowReverse.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnShowReverse.Name = "btnShowReverse";
            this.btnShowReverse.Size = new System.Drawing.Size(199, 65);
            this.btnShowReverse.TabIndex = 1;
            this.btnShowReverse.Text = "Ex.1 Show reverse";
            this.btnShowReverse.UseVisualStyleBackColor = true;
            this.btnShowReverse.Click += new System.EventHandler(this.BtnShowReverse_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(292, 48);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 65);
            this.button1.TabIndex = 2;
            this.button1.Text = "Ex. 2 Calcular ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Location = new System.Drawing.Point(468, 48);
            this.btnTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(141, 65);
            this.btnTotal.TabIndex = 3;
            this.btnTotal.Text = "Ex. 3 Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.BtnTotal_Click);
            // 
            // btnRemoveOtavio
            // 
            this.btnRemoveOtavio.Location = new System.Drawing.Point(656, 48);
            this.btnRemoveOtavio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveOtavio.Name = "btnRemoveOtavio";
            this.btnRemoveOtavio.Size = new System.Drawing.Size(141, 65);
            this.btnRemoveOtavio.TabIndex = 4;
            this.btnRemoveOtavio.Text = "Ex. 4 Otávio";
            this.btnRemoveOtavio.UseVisualStyleBackColor = true;
            this.btnRemoveOtavio.Click += new System.EventHandler(this.BtnRemoveOtavio_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(843, 48);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(4);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(141, 65);
            this.btnMedia.TabIndex = 5;
            this.btnMedia.Text = "Ex. 5 Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Fuchsia;
            this.button2.ForeColor = System.Drawing.SystemColors.Control;
            this.button2.Location = new System.Drawing.Point(468, 224);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 65);
            this.button2.TabIndex = 6;
            this.button2.Text = "Ex.6";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnNewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnRemoveOtavio);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnShowReverse);
            this.Controls.Add(this.btnLoad);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "btnNewForm";
            this.Text = "Exercício1";
            this.Load += new System.EventHandler(this.btnNewForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnShowReverse;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnRemoveOtavio;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button button2;
    }
}