﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class btnNewForm : Form
    {
        private const int NumeroAlunos = 20;
        private const int NumeroNotas = 3;
        private int[] numbers = new int[20];
        private int[] quantities = new int[10];
        private decimal[] prices = new decimal[10];
        private ArrayList alunos = new ArrayList();
        private double[,] notas;
        public btnNewForm()
        {
          
            InitializeComponent();
            notas = new double[NumeroAlunos,NumeroNotas];
            alunos.AddRange(new string[] { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" });
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox($"Digite o número {i + 1}:", "Number Input");
                int number;

                if (!int.TryParse(input, out number))
                {
                    MessageBox.Show("Valor inválido. Por favor digite um inteiro.");
                    i--;
                    continue;
                }

                numbers[i] = number;
            }
        }

        private void BtnShowReverse_Click(object sender, EventArgs e)
   
            
            {
                Array.Reverse(numbers);

                string result = string.Join(", ", numbers);
                MessageBox.Show($"Números na ordem reversa: {result}");
            }

        private void Button1_Click(object sender, EventArgs e)
        {
            decimal totalRevenue = 0;

            for (int i = 0; i < quantities.Length; i++)
            {
                string quantityInput = Microsoft.VisualBasic.Interaction.InputBox($"Digite a quantidade de vendas do item {i + 1}:", "Quantity Input");
                int quantity;

                if (!int.TryParse(quantityInput, out quantity))
                {
                    MessageBox.Show("Valor inválido. Por favor digite um inteiro.");
                    i--;
                    continue;
                }

                string priceInput = Microsoft.VisualBasic.Interaction.InputBox($"Digite o preço do item {i + 1}:", "Price Input");
                decimal price;

                if (!decimal.TryParse(priceInput, out price))
                {
                    MessageBox.Show("Valor inválido. Por favor digite um decimal.");
                    i--;
                    continue;
                }

                quantities[i] = quantity;
                prices[i] = price;

                decimal itemRevenue = quantity * price;
                totalRevenue += itemRevenue;
            }

            MessageBox.Show($"Faturamento mensal total: {totalRevenue.ToString("C")}");
        }

        private void BtnTotal_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" }; Int32 I, Total = 0; Int32 N = Alunos.Length; for (I = 0; I < N - 1; I++) { Total += Alunos[I].Length; }
            MessageBox.Show(Total.ToString());
        }

        private void BtnRemoveOtavio_Click(object sender, EventArgs e)
        {
            alunos.Remove("Otávio");

            MessageBox.Show("Alunos (sem Otávio):" + Environment.NewLine + string.Join(Environment.NewLine, alunos.ToArray()));
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            for(int aluno=0;aluno<NumeroAlunos;aluno++)
            {
                double somaNotas = 0;
                for(int nota=0;nota<NumeroNotas;nota++)
                {
                    string input = Microsoft.VisualBasic.Interaction.InputBox($"Digite a nota{nota + 1} do aluno{aluno + 1}");
                    if(!double.TryParse(input,out notas[aluno, nota]))
                    {
                        MessageBox.Show("Por favor insira um valor numérico válido");
                        return;
                    }
                    somaNotas += notas[aluno,nota];
                }
                double media = somaNotas / NumeroNotas;
                MessageBox.Show($"Aluno {aluno + 1}: média: {media.ToString("F1")}");
            }

        }

        private void btnNewForm_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Exercicio6 exercicio6 = new Exercicio6();
            exercicio6.Show();
        }
    }
}

