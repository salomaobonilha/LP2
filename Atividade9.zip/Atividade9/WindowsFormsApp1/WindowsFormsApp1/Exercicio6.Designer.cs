﻿namespace WindowsFormsApp1
{
    partial class Exercicio6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox = new System.Windows.Forms.ListBox();
            this.loadNamesButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 16;
            this.listBox.Location = new System.Drawing.Point(451, 47);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(219, 308);
            this.listBox.TabIndex = 0;
            // 
            // loadNamesButton
            // 
            this.loadNamesButton.Location = new System.Drawing.Point(150, 126);
            this.loadNamesButton.Name = "loadNamesButton";
            this.loadNamesButton.Size = new System.Drawing.Size(143, 49);
            this.loadNamesButton.TabIndex = 1;
            this.loadNamesButton.Text = "Carregar nomes";
            this.loadNamesButton.UseVisualStyleBackColor = true;
            this.loadNamesButton.Click += new System.EventHandler(this.loadNamesButton_Click);
            // 
            // Exercicio6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.loadNamesButton);
            this.Controls.Add(this.listBox);
            this.Name = "Exercicio6";
            this.Text = "Exercicio6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button loadNamesButton;
    }
}