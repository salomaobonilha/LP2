﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
    
{
    public partial class Exercicio6 : Form
    {
        private string[] nomes;
        private int[] comprimentos;
        public Exercicio6()
        {
            InitializeComponent();
            nomes = new string[GetN()];
            comprimentos = new int[GetN()];
        }
        private int GetN()
        {
            string ra = "12345"; // Substitua pelo seu RA
            int ultimoDigito = int.Parse(ra.Substring(ra.Length - 1));
            int n = 0;

            if (ultimoDigito == 0)
                n = 10;
            else if (ultimoDigito == 1)
                n = 1;
            else
                n = ultimoDigito;

            return n;
        }

        private void loadNamesButton_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < nomes.Length; i++)
            {
                string nome = Microsoft.VisualBasic.Interaction.InputBox($"Digite o nome completo da pessoa {i + 1}:");
                nomes[i] = nome;
                comprimentos[i] = nome.Replace(" ", "").Length;
            }

            UpdateListBox();
        }

        private void UpdateListBox()
        {
            listBox.Items.Clear();

            for (int i = 0; i < nomes.Length; i++)
            {
                string nome = nomes[i];
                int comprimento = comprimentos[i];
                listBox.Items.Add($"{nome} - Comprimento: {comprimento}");
            }
        }

    }
}
