﻿namespace WindowsFormsApp1
{
    partial class btnCalculate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnShowReverse = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnRemoveOtavio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(21, 39);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(149, 53);
            this.btnLoad.TabIndex = 0;
            this.btnLoad.Text = "Ex. 1 Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.BtnLoad_Click);
            // 
            // btnShowReverse
            // 
            this.btnShowReverse.Location = new System.Drawing.Point(21, 98);
            this.btnShowReverse.Name = "btnShowReverse";
            this.btnShowReverse.Size = new System.Drawing.Size(149, 53);
            this.btnShowReverse.TabIndex = 1;
            this.btnShowReverse.Text = "Ex.1 Show reverse";
            this.btnShowReverse.UseVisualStyleBackColor = true;
            this.btnShowReverse.Click += new System.EventHandler(this.BtnShowReverse_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(219, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 53);
            this.button1.TabIndex = 2;
            this.button1.Text = "Ex. 2 Calcular ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Location = new System.Drawing.Point(351, 39);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(106, 53);
            this.btnTotal.TabIndex = 3;
            this.btnTotal.Text = "Ex. 3 Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.BtnTotal_Click);
            // 
            // btnRemoveOtavio
            // 
            this.btnRemoveOtavio.Location = new System.Drawing.Point(492, 39);
            this.btnRemoveOtavio.Name = "btnRemoveOtavio";
            this.btnRemoveOtavio.Size = new System.Drawing.Size(106, 53);
            this.btnRemoveOtavio.TabIndex = 4;
            this.btnRemoveOtavio.Text = "Ex. 4 Otávio";
            this.btnRemoveOtavio.UseVisualStyleBackColor = true;
            this.btnRemoveOtavio.Click += new System.EventHandler(this.BtnRemoveOtavio_Click);
            // 
            // btnCalculate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRemoveOtavio);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnShowReverse);
            this.Controls.Add(this.btnLoad);
            this.Name = "btnCalculate";
            this.Text = "Exercício1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnShowReverse;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnRemoveOtavio;
    }
}