﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482223012
{
    public partial class frmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();
        public frmContato()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
               tbContato.SelectTab(1);
            }
            bnContato.AddNew();
            txtNomeContato.Enabled = true;
            cbxCidade.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            txtNomeContato.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true; ;
        }

        private void txtNomeCidade_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNomeContato.Text == "")
            {
                MessageBox.Show("Contato inválido!");
            }
            else if (txtIdContato.Text == "")
            {
                MessageBox.Show("Id inválido!");
            }
            else if (txtEnd.Text == "")
            {
                MessageBox.Show("Endereço inválido!");
            }
            else if (txtCel.Text == "")
            {
                MessageBox.Show("Celular inválido!");
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("E-mail inválido!");
            }
            else if (cbxCidade.SelectedIndex == -1)
            {
                MessageBox.Show("Contato inválido!");
            }
            else
            {
                Contato RegCont = new Contato();
                RegCont.Nomecontato = txtNomeContato.Text;
                RegCont.Endcontato = txtEnd.Text;
                RegCont.Cidadeidcidade=Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegCont.Celcontato = txtCel.Text;
                RegCont.Emailcontato = txtEmail.Text;
                RegCont.Dtcadastrocontato = dateTimePicker.Value;
                if (bInclusao)
                {
                    if (RegCont.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionada com sucesso!");
                        btnSalvar.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtNomeContato.Enabled = false;
                        cbxCidade.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                        bInclusao = false;
                        // recarrega o grid
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCont.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato!");
                    }
                }
                else
                {
                    RegCont.Idcontato = Convert.ToInt16(txtIdContato.Text);
                    if (RegCont.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterada com sucesso!");
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCont.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                        txtNomeContato.Enabled = false;
                        cbxCidade.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato!");
                    }
                }
            }
        }

        private void frmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtIdContato.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEnd.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCel.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
                dateTimePicker.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];

                cbxCidade.DisplayMember = "nome_cidade";

                cbxCidade.ValueMember = "id_cidade";

                cbxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            txtNomeContato.Enabled = true;
            cbxCidade.Enabled = true;
            txtNomeContato.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)== DialogResult.Yes)
            {
                Contato RegCont = new Contato();
                //RegCont.Nomecontato = txtNomeContato.Text;
                //RegCont.Endcontato = txtEnd.Text;
                //RegCont.Cidadeidcidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                //RegCont.Celcontato = txtCel.Text;
                //RegCont.Emailcontato = txtEmail.Text;
                //RegCont.Dtcadastrocontato = dateTimePicker.Value;
                RegCont.Idcontato =Convert.ToInt32 (txtIdContato.Text);
                if (RegCont.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluído com sucesso!");
                    Contato R = new Contato();
                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(R.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();
            btnSalvar.Enabled = false;
            txtNomeContato.Enabled = false;
            cbxCidade.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

