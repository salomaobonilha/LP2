﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482223012
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data source=LENOVOSALOMAO\\SQLEXPRESS;Initial Catalog=LP2;Integrated Security=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/"+ex.Message);
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Outros erros =/" + ex.Message);
            }

        }

        private void cadastrosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCidade Form = new frmCidade();
            Form.Show();
        }

        private void aiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cadastrosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void cidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                MessageBox.Show("Form já existe!");
                Application.OpenForms["frmCidade"].BringToFront();
            }
            else
            {
                frmCidade objc = new frmCidade();
                objc.MdiParent = this;
                objc.WindowState = FormWindowState.Maximized;
                objc.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sobre Form = new Sobre();
            Form.Show();
        }

        private void contatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count()>0)
            {
                MessageBox.Show("Form já existe!");
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato objc = new frmContato();
                objc.MdiParent = this;
                objc.WindowState = FormWindowState.Maximized;
                objc.Show();
            }
        }
    }
}
