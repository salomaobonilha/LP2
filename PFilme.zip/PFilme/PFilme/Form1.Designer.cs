﻿namespace PFilme
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExe = new System.Windows.Forms.Button();
            this.lbxFilme = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnExe
            // 
            this.btnExe.Location = new System.Drawing.Point(58, 140);
            this.btnExe.Name = "btnExe";
            this.btnExe.Size = new System.Drawing.Size(121, 89);
            this.btnExe.TabIndex = 0;
            this.btnExe.Text = "Executar";
            this.btnExe.UseVisualStyleBackColor = true;
            this.btnExe.Click += new System.EventHandler(this.BtnExe_Click);
            // 
            // lbxFilme
            // 
            this.lbxFilme.FormattingEnabled = true;
            this.lbxFilme.Location = new System.Drawing.Point(309, 37);
            this.lbxFilme.Name = "lbxFilme";
            this.lbxFilme.Size = new System.Drawing.Size(399, 342);
            this.lbxFilme.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbxFilme);
            this.Controls.Add(this.btnExe);
            this.Name = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExe;
        private System.Windows.Forms.ListBox lbxFilme;
    }
}

