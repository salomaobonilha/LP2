﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExe_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 2];
            string Aux;
            double Media1 = 0;
            double Media2 = 0;
            int i;
            int j;

            lbxFilme.Items.Clear();

            for( i=0; i<=19; i++)
            {



                for(j=0; j<=1; j++)
                {

                    Aux = Interaction.InputBox("Digite a Nota do Filme " + (j + 1), "Dados do Filme Pessoa "+(i+1));

                    if (!double.TryParse(Aux, out Notas[i, j]))
                    {
                        MessageBox.Show("Nota Inválida \n Digite novamente ");
                        j--;
                    }
                    else
                    {

                        if (Notas[i, j] < 0 || Notas[i, j] > 10)
                        {
                            MessageBox.Show("Nota Inválida \n Digite novamente ");
                            j--;
                        }
                        else if (j == 0)
                            Media1 += Notas[i, j];
                        else
                            Media2 += Notas[i, j];


                    }
                            


                }









            }

            Media1 /= 20;
            Media2 /= 20;


            for (i = 0; i <= 19; i++)
                lbxFilme.Items.Add("Pessoa " + (i + 1) + " Nota Filme 1: " + Notas[i, 0].ToString("N2") + " Nota Filme 2: " + Notas[i, 1].ToString("N2"));

            lbxFilme.Items.Add("--------------------------------------------------------------------------");
            lbxFilme.Items.Add("Média Filme 1: " + Media1.ToString("N2"));
            lbxFilme.Items.Add("Média Filme 2: " + Media2.ToString("N2"));




        }
    }
}
