﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void COPIARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Selecionou ctrl+C");
        }

        private void COLARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Selecionou ctrl+V");
        }

        private void Exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmexercicio2 objfrm2 = new frmexercicio2();
            objfrm2.MdiParent = this;
            objfrm2.WindowState = FormWindowState.Maximized;
            objfrm2.Show();
        }

        private void Exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmexercicio3 objfrm3 = new frmexercicio3();
            objfrm3.MdiParent = this;
            objfrm3.WindowState = FormWindowState.Maximized;
            objfrm3.Show();
        }

        private void Exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmexercicio4 objfrm4 = new frmexercicio4();
            objfrm4.MdiParent = this;
            objfrm4.WindowState = FormWindowState.Maximized;
            objfrm4.Show();
        }

        private void Exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmexercicio5 objfrm5 = new frmexercicio5();
            objfrm5.MdiParent = this;
            objfrm5.WindowState = FormWindowState.Maximized;
            objfrm5.Show();
        }
    }
}
