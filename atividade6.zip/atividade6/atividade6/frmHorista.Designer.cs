﻿namespace atividade6
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSalHor = new System.Windows.Forms.Label();
            this.lblNumHor = new System.Windows.Forms.Label();
            this.lblDiasFalt = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblMat = new System.Windows.Forms.Label();
            this.GbxHome = new System.Windows.Forms.GroupBox();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMat = new System.Windows.Forms.TextBox();
            this.txtSalHora = new System.Windows.Forms.TextBox();
            this.txtNumHor = new System.Windows.Forms.TextBox();
            this.txtDiasFalt = new System.Windows.Forms.TextBox();
            this.btnInstHor = new System.Windows.Forms.Button();
            this.GbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSalHor
            // 
            this.lblSalHor.AutoSize = true;
            this.lblSalHor.Location = new System.Drawing.Point(135, 184);
            this.lblSalHor.Name = "lblSalHor";
            this.lblSalHor.Size = new System.Drawing.Size(65, 13);
            this.lblSalHor.TabIndex = 0;
            this.lblSalHor.Text = "Salário Hora";
            // 
            // lblNumHor
            // 
            this.lblNumHor.AutoSize = true;
            this.lblNumHor.Location = new System.Drawing.Point(112, 214);
            this.lblNumHor.Name = "lblNumHor";
            this.lblNumHor.Size = new System.Drawing.Size(88, 13);
            this.lblNumHor.TabIndex = 1;
            this.lblNumHor.Text = "Número de horas";
            // 
            // lblDiasFalt
            // 
            this.lblDiasFalt.AutoSize = true;
            this.lblDiasFalt.Location = new System.Drawing.Point(134, 244);
            this.lblDiasFalt.Name = "lblDiasFalt";
            this.lblDiasFalt.Size = new System.Drawing.Size(66, 13);
            this.lblDiasFalt.TabIndex = 2;
            this.lblDiasFalt.Text = "Dias de falta";
            this.lblDiasFalt.Click += new System.EventHandler(this.Label3_Click);
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(58, 154);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(142, 13);
            this.lblData.TabIndex = 11;
            this.lblData.Text = "Data de entrada na empresa";
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(94, 124);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(106, 13);
            this.lblNom.TabIndex = 10;
            this.lblNom.Text = "Nome do empregado";
            // 
            // lblMat
            // 
            this.lblMat.AutoSize = true;
            this.lblMat.Location = new System.Drawing.Point(150, 94);
            this.lblMat.Name = "lblMat";
            this.lblMat.Size = new System.Drawing.Size(50, 13);
            this.lblMat.TabIndex = 9;
            this.lblMat.Text = "Matricula";
            // 
            // GbxHome
            // 
            this.GbxHome.Controls.Add(this.rbtnNao);
            this.GbxHome.Controls.Add(this.rbtnSim);
            this.GbxHome.Location = new System.Drawing.Point(480, 94);
            this.GbxHome.Name = "GbxHome";
            this.GbxHome.Size = new System.Drawing.Size(200, 100);
            this.GbxHome.TabIndex = 12;
            this.GbxHome.TabStop = false;
            this.GbxHome.Text = "Trabalha em home office?";
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(20, 65);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(45, 17);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "Não";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(20, 42);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(42, 17);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(223, 152);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 20);
            this.txtData.TabIndex = 16;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(223, 123);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(208, 20);
            this.txtNome.TabIndex = 15;
            // 
            // txtMat
            // 
            this.txtMat.Location = new System.Drawing.Point(223, 94);
            this.txtMat.Name = "txtMat";
            this.txtMat.Size = new System.Drawing.Size(100, 20);
            this.txtMat.TabIndex = 14;
            // 
            // txtSalHora
            // 
            this.txtSalHora.Location = new System.Drawing.Point(223, 184);
            this.txtSalHora.Name = "txtSalHora";
            this.txtSalHora.Size = new System.Drawing.Size(100, 20);
            this.txtSalHora.TabIndex = 17;
            // 
            // txtNumHor
            // 
            this.txtNumHor.Location = new System.Drawing.Point(223, 214);
            this.txtNumHor.Name = "txtNumHor";
            this.txtNumHor.Size = new System.Drawing.Size(100, 20);
            this.txtNumHor.TabIndex = 18;
            // 
            // txtDiasFalt
            // 
            this.txtDiasFalt.Location = new System.Drawing.Point(223, 244);
            this.txtDiasFalt.Name = "txtDiasFalt";
            this.txtDiasFalt.Size = new System.Drawing.Size(100, 20);
            this.txtDiasFalt.TabIndex = 19;
            // 
            // btnInstHor
            // 
            this.btnInstHor.Location = new System.Drawing.Point(207, 285);
            this.btnInstHor.Name = "btnInstHor";
            this.btnInstHor.Size = new System.Drawing.Size(130, 23);
            this.btnInstHor.TabIndex = 20;
            this.btnInstHor.Text = "Intanciar horista";
            this.btnInstHor.UseVisualStyleBackColor = true;
            this.btnInstHor.Click += new System.EventHandler(this.BtnInstHor_Click);
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInstHor);
            this.Controls.Add(this.txtDiasFalt);
            this.Controls.Add(this.txtNumHor);
            this.Controls.Add(this.txtSalHora);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMat);
            this.Controls.Add(this.GbxHome);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.lblMat);
            this.Controls.Add(this.lblDiasFalt);
            this.Controls.Add(this.lblNumHor);
            this.Controls.Add(this.lblSalHor);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.GbxHome.ResumeLayout(false);
            this.GbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSalHor;
        private System.Windows.Forms.Label lblNumHor;
        private System.Windows.Forms.Label lblDiasFalt;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblMat;
        private System.Windows.Forms.GroupBox GbxHome;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMat;
        private System.Windows.Forms.TextBox txtSalHora;
        private System.Windows.Forms.TextBox txtNumHor;
        private System.Windows.Forms.TextBox txtDiasFalt;
        private System.Windows.Forms.Button btnInstHor;
    }
}