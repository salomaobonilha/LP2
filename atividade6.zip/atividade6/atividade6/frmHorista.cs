﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade6
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void BtnInstHor_Click(object sender, EventArgs e)
        {
            horista objHorista = new horista();
            objHorista.Matricula = Convert.ToInt32(txtMat.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumHor.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFalt.Text);
            if (rbtnSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';
            MessageBox.Show("Matrícula: " + objHorista.Matricula +
                "\n" + "Nome: " + objHorista.NomeEmpregado + "\n" +
                "Data de entrada: " +
                objHorista.DataEntradaEmpresa.ToShortDateString()
                + "\n" + "Salário bruto: " +
                objHorista.SalarioBruto().ToString("N2")
                + "\n" + "Tempo de empresa (dias): " +
                objHorista.TempoTrabalho() + "\n" +
                objHorista.VerificaHome());
        }
    }
}
