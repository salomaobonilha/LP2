﻿namespace atividade6
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSalMens = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblMat = new System.Windows.Forms.Label();
            this.GbxHome = new System.Windows.Forms.GroupBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.txtMat = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtSal = new System.Windows.Forms.TextBox();
            this.btnInstMens = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.GbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSalMens
            // 
            this.lblSalMens.AutoSize = true;
            this.lblSalMens.Location = new System.Drawing.Point(113, 175);
            this.lblSalMens.Name = "lblSalMens";
            this.lblSalMens.Size = new System.Drawing.Size(75, 13);
            this.lblSalMens.TabIndex = 9;
            this.lblSalMens.Text = "Salário mensal";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(46, 146);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(142, 13);
            this.lblData.TabIndex = 7;
            this.lblData.Text = "Data de entrada na empresa";
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(82, 117);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(106, 13);
            this.lblNom.TabIndex = 6;
            this.lblNom.Text = "Nome do empregado";
            // 
            // lblMat
            // 
            this.lblMat.AutoSize = true;
            this.lblMat.Location = new System.Drawing.Point(138, 88);
            this.lblMat.Name = "lblMat";
            this.lblMat.Size = new System.Drawing.Size(50, 13);
            this.lblMat.TabIndex = 5;
            this.lblMat.Text = "Matricula";
            // 
            // GbxHome
            // 
            this.GbxHome.Controls.Add(this.rbtnNao);
            this.GbxHome.Controls.Add(this.rbtnSim);
            this.GbxHome.Location = new System.Drawing.Point(530, 88);
            this.GbxHome.Name = "GbxHome";
            this.GbxHome.Size = new System.Drawing.Size(200, 100);
            this.GbxHome.TabIndex = 10;
            this.GbxHome.TabStop = false;
            this.GbxHome.Text = "Trabalha em home office?";
            this.GbxHome.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(20, 42);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(42, 17);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(20, 65);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(45, 17);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "Não";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // txtMat
            // 
            this.txtMat.Location = new System.Drawing.Point(220, 88);
            this.txtMat.Name = "txtMat";
            this.txtMat.Size = new System.Drawing.Size(100, 20);
            this.txtMat.TabIndex = 11;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(220, 117);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(220, 20);
            this.txtNome.TabIndex = 12;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(220, 146);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 20);
            this.txtData.TabIndex = 13;
            // 
            // txtSal
            // 
            this.txtSal.Location = new System.Drawing.Point(220, 175);
            this.txtSal.Name = "txtSal";
            this.txtSal.Size = new System.Drawing.Size(100, 20);
            this.txtSal.TabIndex = 14;
            // 
            // btnInstMens
            // 
            this.btnInstMens.Location = new System.Drawing.Point(58, 252);
            this.btnInstMens.Name = "btnInstMens";
            this.btnInstMens.Size = new System.Drawing.Size(130, 23);
            this.btnInstMens.TabIndex = 15;
            this.btnInstMens.Text = "Intanciar mensalista";
            this.btnInstMens.UseVisualStyleBackColor = true;
            this.btnInstMens.Click += new System.EventHandler(this.BtnInstMens_Click);
            // 
            // btnPar
            // 
            this.btnPar.Location = new System.Drawing.Point(220, 252);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(220, 23);
            this.btnPar.TabIndex = 16;
            this.btnPar.Text = "Instanciar mensalista passando parâmetros";
            this.btnPar.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInstMens);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.txtSal);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMat);
            this.Controls.Add(this.GbxHome);
            this.Controls.Add(this.lblSalMens);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.lblMat);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.GbxHome.ResumeLayout(false);
            this.GbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSalMens;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblMat;
        private System.Windows.Forms.GroupBox GbxHome;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.TextBox txtMat;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtSal;
        private System.Windows.Forms.Button btnInstMens;
        private System.Windows.Forms.Button btnPar;
    }
}