﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade6
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BtnInstMens_Click(object sender, EventArgs e)
        {
            mensalista objMensalista = new mensalista();
            objMensalista.Matricula = Convert.ToInt32(txtMat.Text);
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSal.Text);
            if (rbtnSim.Checked)
                objMensalista.HomeOffice = 'S';
            else
                objMensalista.HomeOffice = 'N';
            MessageBox.Show("Matrícula: " + objMensalista.Matricula + 
                "\n" + "Nome: " + objMensalista.NomeEmpregado + "\n" +
                "Data de entrada: " + 
                objMensalista.DataEntradaEmpresa.ToShortDateString()
                + "\n" + "Salário bruto: " + 
                objMensalista.SalarioBruto().ToString("N2")
                + "\n" + "Tempo de empresa (dias): " + 
                objMensalista.TempoTrabalho() + "\n" + 
                objMensalista.VerificaHome());

        }
    }
}
