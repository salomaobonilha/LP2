﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atividade6
{
    class mensalista : empregado
    {

        public Double SalarioMensal { get; set; }
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
    
    }

