﻿namespace WindowsFormsApp1
{
    partial class frmexercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.btncomparar = new System.Windows.Forms.Button();
            this.btnserie1 = new System.Windows.Forms.Button();
            this.btnserie2 = new System.Windows.Forms.Button();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(83, 82);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra1.TabIndex = 0;
            this.lblpalavra1.Text = "Palavra 1";
            this.lblpalavra1.Click += new System.EventHandler(this.Lblpalavra1_Click);
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(157, 146);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra2.TabIndex = 2;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(157, 82);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra1.TabIndex = 3;
            // 
            // btncomparar
            // 
            this.btncomparar.Location = new System.Drawing.Point(101, 240);
            this.btncomparar.Name = "btncomparar";
            this.btncomparar.Size = new System.Drawing.Size(75, 43);
            this.btncomparar.TabIndex = 4;
            this.btncomparar.Text = "Verifica se são iguais";
            this.btncomparar.UseVisualStyleBackColor = true;
            this.btncomparar.Click += new System.EventHandler(this.Btncomparar_Click);
            // 
            // btnserie1
            // 
            this.btnserie1.Location = new System.Drawing.Point(182, 240);
            this.btnserie1.Name = "btnserie1";
            this.btnserie1.Size = new System.Drawing.Size(75, 43);
            this.btnserie1.TabIndex = 5;
            this.btnserie1.Text = "insere 1° no meio do segundo";
            this.btnserie1.UseVisualStyleBackColor = true;
            this.btnserie1.Click += new System.EventHandler(this.Btnserie1_Click);
            // 
            // btnserie2
            // 
            this.btnserie2.Location = new System.Drawing.Point(263, 240);
            this.btnserie2.Name = "btnserie2";
            this.btnserie2.Size = new System.Drawing.Size(81, 43);
            this.btnserie2.TabIndex = 6;
            this.btnserie2.Text = "insere ** no meio 1°";
            this.btnserie2.UseVisualStyleBackColor = true;
            this.btnserie2.Click += new System.EventHandler(this.Btnserie2_Click);
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(83, 153);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra2.TabIndex = 7;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // frmexercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.btnserie2);
            this.Controls.Add(this.btnserie1);
            this.Controls.Add(this.btncomparar);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmexercicio2";
            this.Text = "frmexercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Button btncomparar;
        private System.Windows.Forms.Button btnserie1;
        private System.Windows.Forms.Button btnserie2;
        private System.Windows.Forms.Label lblpalavra2;
    }
}