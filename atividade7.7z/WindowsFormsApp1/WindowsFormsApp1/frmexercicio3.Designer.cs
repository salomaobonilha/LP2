﻿namespace WindowsFormsApp1
{
    partial class frmexercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.btninverte = new System.Windows.Forms.Button();
            this.btnreplace = new System.Windows.Forms.Button();
            this.btnremover = new System.Windows.Forms.Button();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(69, 121);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra2.TabIndex = 14;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // btninverte
            // 
            this.btninverte.Location = new System.Drawing.Point(343, 198);
            this.btninverte.Name = "btninverte";
            this.btninverte.Size = new System.Drawing.Size(136, 53);
            this.btninverte.TabIndex = 13;
            this.btninverte.Text = "inverte palavra 1";
            this.btninverte.UseVisualStyleBackColor = true;
            this.btninverte.Click += new System.EventHandler(this.Btninverte_Click);
            // 
            // btnreplace
            // 
            this.btnreplace.Location = new System.Drawing.Point(199, 198);
            this.btnreplace.Name = "btnreplace";
            this.btnreplace.Size = new System.Drawing.Size(138, 53);
            this.btnreplace.TabIndex = 12;
            this.btnreplace.Text = "Remove ocorrências do 1° no 2°(replace)";
            this.btnreplace.UseVisualStyleBackColor = true;
            this.btnreplace.Click += new System.EventHandler(this.Btnreplace_Click);
            // 
            // btnremover
            // 
            this.btnremover.Location = new System.Drawing.Point(72, 198);
            this.btnremover.Name = "btnremover";
            this.btnremover.Size = new System.Drawing.Size(121, 53);
            this.btnremover.TabIndex = 11;
            this.btnremover.Text = "Remove ocorrências do 1° no 2°";
            this.btnremover.UseVisualStyleBackColor = true;
            this.btnremover.Click += new System.EventHandler(this.Btnremover_Click);
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(143, 50);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra1.TabIndex = 10;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(143, 114);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra2.TabIndex = 9;
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(69, 50);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra1.TabIndex = 8;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // frmexercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.btninverte);
            this.Controls.Add(this.btnreplace);
            this.Controls.Add(this.btnremover);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmexercicio3";
            this.Text = "frmexercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Button btninverte;
        private System.Windows.Forms.Button btnreplace;
        private System.Windows.Forms.Button btnremover;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
    }
}