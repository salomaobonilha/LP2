﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmexercicio3 : Form
    {
        public frmexercicio3()
        {
            InitializeComponent();
        }

        private void Btnremover_Click(object sender, EventArgs e)
        {
            int posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);
            while (posicao >= 0)
            {
                txtpalavra2.Text = txtpalavra2.Text.Substring(0, posicao) +
                    txtpalavra2.Text.Substring(txtpalavra1.Text.Length + posicao,
                    txtpalavra2.Text.Length - posicao - txtpalavra1.Text.Length);
                posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);
            }
        }

        private void Btnreplace_Click(object sender, EventArgs e)
        {
            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text, "");
        }

        private void Btninverte_Click(object sender, EventArgs e)
        {
            char[] meuArray = txtpalavra1.Text.ToCharArray();
            Array.Reverse(meuArray);

            foreach (var c in meuArray)
                txtpalavra2.Text += c;
            //MessageBox.Show(txtpalavra2.Text);
        }
    }
}
